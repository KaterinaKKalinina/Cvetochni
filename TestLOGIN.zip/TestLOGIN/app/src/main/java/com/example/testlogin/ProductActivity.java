package com.example.testlogin;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ProductActivity extends AppCompatActivity {

    private RecyclerView recyclerViewProducts;
    private ProductAdapter productAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        recyclerViewProducts = findViewById(R.id.recyclerViewProducts);
        recyclerViewProducts.setLayoutManager(new LinearLayoutManager(this));

        List<Product> productList = new ArrayList<>();

        // Добавьте товары в список (замените на ваши данные)
        productList.add(new Product("Товар 1", "Цена: 1000 руб.", R.drawable.product1));
        productList.add(new Product("Товар 2", "Цена: 1500 руб.", R.drawable.product2));
        productList.add(new Product("Товар 3", "Цена: 2000 руб.", R.drawable.product3));

        // Инициализация адаптера и установка его в RecyclerView
        productAdapter = new ProductAdapter(productList);
        recyclerViewProducts.setAdapter(productAdapter);
    }
}